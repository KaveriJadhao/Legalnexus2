import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Scale, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useMember } from '@/integrations';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { member, isAuthenticated, isLoading, actions } = useMember();

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Submit Case', path: '/submit-case' },
    { name: 'Lawyers', path: '/lawyers' },
    { name: 'Dashboard', path: '/dashboard' },
    { name: 'FAQ', path: '/faq' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-sm border-b border-foreground/10">
      <nav className="max-w-[100rem] mx-auto px-8 lg:px-16 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-foreground/10 rounded-lg flex items-center justify-center group-hover:bg-foreground/20 transition-colors duration-300">
              <Scale className="w-6 h-6 text-foreground" />
            </div>
            <span className="font-heading text-2xl font-bold text-foreground">
              Legal<span className="text-foreground/70">Nexus</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-paragraph text-sm font-medium transition-colors duration-300 ${
                  isActive(link.path)
                    ? 'text-foreground'
                    : 'text-foreground/60 hover:text-foreground'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Auth Section */}
          <div className="hidden lg:flex items-center gap-4">
            {isLoading ? (
              <div className="w-8 h-8 border-2 border-foreground/30 border-t-foreground rounded-full animate-spin" />
            ) : isAuthenticated ? (
              <>
                <Link to="/profile">
                  <Button variant="outline" className="border-foreground/30 text-foreground hover:bg-foreground/10 font-paragraph">
                    {member?.profile?.nickname || member?.contact?.firstName || 'Profile'}
                  </Button>
                </Link>
                <Button
                  onClick={actions.logout}
                  variant="outline"
                  className="border-foreground/20 text-foreground hover:bg-foreground/10 font-paragraph"
                >
                  Sign Out
                </Button>
              </>
            ) : (
              <Button
                onClick={actions.login}
                className="bg-foreground text-white hover:bg-foreground/90 font-heading font-semibold"
              >
                Sign In
              </Button>
            )}
            
            <Link to="/admin">
              <Button variant="outline" className="border-foreground/30 text-foreground hover:bg-foreground/10 font-paragraph">
                Admin
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-foreground hover:text-foreground/70 transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 space-y-4 border-t border-foreground/10 pt-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`block font-paragraph text-sm font-medium transition-colors duration-300 ${
                  isActive(link.path)
                    ? 'text-foreground'
                    : 'text-foreground/60 hover:text-foreground'
                }`}
              >
                {link.name}
              </Link>
            ))}
            
            <div className="pt-4 space-y-2 border-t border-foreground/10">
              {isLoading ? (
                <div className="w-8 h-8 border-2 border-foreground/30 border-t-foreground rounded-full animate-spin" />
              ) : isAuthenticated ? (
                <>
                  <Link to="/profile" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="outline" className="w-full border-foreground/30 text-foreground hover:bg-foreground/10 font-paragraph">
                      {member?.profile?.nickname || member?.contact?.firstName || 'Profile'}
                    </Button>
                  </Link>
                  <Button
                    onClick={() => {
                      actions.logout();
                      setMobileMenuOpen(false);
                    }}
                    variant="outline"
                    className="w-full border-foreground/20 text-foreground hover:bg-foreground/10 font-paragraph"
                  >
                    Sign Out
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => {
                    actions.login();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full bg-foreground text-white hover:bg-foreground/90 font-heading font-semibold"
                >
                  Sign In
                </Button>
              )}
              
              <Link to="/admin" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="outline" className="w-full border-foreground/30 text-foreground hover:bg-foreground/10 font-paragraph">
                  Admin
                </Button>
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
