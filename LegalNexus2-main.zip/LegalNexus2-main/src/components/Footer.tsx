import { Link } from 'react-router-dom';
import { Scale, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="w-full bg-white border-t border-foreground/10">
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-foreground/10 rounded-lg flex items-center justify-center group-hover:bg-foreground/20 transition-colors duration-300">
                <Scale className="w-6 h-6 text-foreground" />
              </div>
              <span className="font-heading text-2xl font-bold text-foreground">
                Legal<span className="text-foreground/70">Nexus</span>
              </span>
            </Link>
            <p className="font-paragraph text-sm text-foreground/60 leading-relaxed">
              Professional legal platform connecting clients with expert lawyers for efficient case management and resolution.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h3 className="font-heading text-lg font-semibold text-foreground">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/submit-case" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Submit Case
                </Link>
              </li>
              <li>
                <Link to="/lawyers" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Browse Lawyers
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/faq" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Legal FAQ
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-6">
            <h3 className="font-heading text-lg font-semibold text-foreground">Legal</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/privacy" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/disclaimer" className="font-paragraph text-sm text-foreground/60 hover:text-foreground transition-colors duration-300">
                  Legal Disclaimer
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-6">
            <h3 className="font-heading text-lg font-semibold text-foreground">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-foreground mt-0.5 flex-shrink-0" />
                <span className="font-paragraph text-sm text-foreground/60">
                  support@legalnexus.com
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-foreground mt-0.5 flex-shrink-0" />
                <span className="font-paragraph text-sm text-foreground/60">
                  +1 (555) 123-4567
                </span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-foreground mt-0.5 flex-shrink-0" />
                <span className="font-paragraph text-sm text-foreground/60">
                  123 Legal Street, Justice City, LC 12345
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-foreground/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="font-paragraph text-sm text-foreground/50">
              © {new Date().getFullYear()} LegalNexus. All rights reserved.
            </p>
            <p className="font-paragraph text-xs text-foreground/40 text-center md:text-right max-w-2xl">
              Disclaimer: This platform provides legal information and connections to legal professionals. It does not constitute legal advice. Consult with a qualified attorney for specific legal matters.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
