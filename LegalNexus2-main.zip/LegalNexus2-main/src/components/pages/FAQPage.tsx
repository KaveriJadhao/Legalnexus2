import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Send, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BaseCrudService } from '@/integrations';
import { LegalFAQs } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function FAQPage() {
  const [faqs, setFaqs] = useState<LegalFAQs[]>([]);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I\'m your Legal FAQ Assistant. Ask me any legal question, and I\'ll help you find answers.',
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadFAQs();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadFAQs = async () => {
    setIsLoading(true);
    const result = await BaseCrudService.getAll<LegalFAQs>('legalfaqs');
    setFaqs(result.items.sort((a, b) => (b.priorityLevel || 0) - (a.priorityLevel || 0)));
    setIsLoading(false);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const findAnswer = (question: string): string => {
    const lowerQuestion = question.toLowerCase();
    
    // Find FAQ by keyword matching
    for (const faq of faqs) {
      const keywords = faq.keywords?.toLowerCase().split(',').map(k => k.trim()) || [];
      const questionText = faq.questionText?.toLowerCase() || '';
      
      if (keywords.some(keyword => lowerQuestion.includes(keyword)) || 
          lowerQuestion.includes(questionText)) {
        return faq.answerText || 'I found a related answer, but the details are not available.';
      }
    }

    // Category-based matching
    const categoryMatches = faqs.filter(faq => {
      const category = faq.category?.toLowerCase() || '';
      return lowerQuestion.includes(category);
    });

    if (categoryMatches.length > 0) {
      const topMatch = categoryMatches[0];
      return topMatch.answerText || 'I found information in this category, but specific details are not available.';
    }

    // Default response
    return 'I couldn\'t find a specific answer to your question. Please try rephrasing or contact our support team for personalized assistance. You can also browse our FAQ categories below.';
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);

    // Simulate bot thinking
    setTimeout(() => {
      const answer = findAnswer(inputMessage);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: answer,
        sender: 'bot',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, botMessage]);
    }, 500);

    setInputMessage('');
  };

  const handleQuickQuestion = (question: string) => {
    setInputMessage(question);
  };

  const categories = [...new Set(faqs.map(faq => faq.category).filter(Boolean))];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/20 rounded-2xl mb-6">
            <MessageSquare className="w-10 h-10 text-primary" />
          </div>
          <h1 className="font-heading text-5xl lg:text-6xl font-bold mb-4">
            Legal <span className="text-primary">FAQ Bot</span>
          </h1>
          <p className="font-paragraph text-lg text-foreground/70 max-w-2xl mx-auto">
            Get instant answers to common legal questions through our AI-powered chatbot
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Chat Interface */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="lg:col-span-2 bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl overflow-hidden flex flex-col"
            style={{ height: '700px' }}
          >
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex gap-3 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {message.sender === 'bot' && (
                    <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <Bot className="w-5 h-5 text-primary" />
                    </div>
                  )}
                  
                  <div className={`max-w-[80%] rounded-2xl p-4 ${
                    message.sender === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background/50 text-foreground border border-foreground/10'
                  }`}>
                    <p className="font-paragraph text-sm leading-relaxed">{message.text}</p>
                  </div>

                  {message.sender === 'user' && (
                    <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-secondary" />
                    </div>
                  )}
                </motion.div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSendMessage} className="p-6 border-t border-foreground/10 bg-background/30">
              <div className="flex gap-3">
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Ask a legal question..."
                  className="flex-1 bg-background/50 border-foreground/20 text-foreground font-paragraph"
                />
                <Button
                  type="submit"
                  className="bg-primary text-primary-foreground hover:bg-primary/90 px-6"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </form>
          </motion.div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Questions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6"
            >
              <h2 className="font-heading text-xl font-semibold text-foreground mb-4">
                Quick Questions
              </h2>
              <div className="space-y-2">
                {isLoading ? null : faqs.slice(0, 5).map((faq) => (
                  <button
                    key={faq._id}
                    onClick={() => handleQuickQuestion(faq.questionText || '')}
                    className="w-full text-left p-3 rounded-lg bg-background/30 hover:bg-background/50 border border-foreground/10 hover:border-primary/30 transition-all duration-300"
                  >
                    <p className="font-paragraph text-sm text-foreground/80 line-clamp-2">
                      {faq.questionText}
                    </p>
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Categories */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6"
            >
              <h2 className="font-heading text-xl font-semibold text-foreground mb-4">
                Categories
              </h2>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => handleQuickQuestion(`Tell me about ${category}`)}
                    className="w-full text-left px-4 py-2 rounded-lg bg-primary/10 hover:bg-primary/20 border border-primary/20 hover:border-primary/40 transition-all duration-300"
                  >
                    <p className="font-paragraph text-sm text-primary font-semibold">
                      {category}
                    </p>
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6"
            >
              <h2 className="font-heading text-xl font-semibold text-foreground mb-3">
                How It Works
              </h2>
              <ul className="space-y-3 font-paragraph text-sm text-foreground/70">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Type your legal question in the chat</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>AI analyzes keywords and matches FAQs</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Get instant answers from our database</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Use quick questions for common topics</span>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
