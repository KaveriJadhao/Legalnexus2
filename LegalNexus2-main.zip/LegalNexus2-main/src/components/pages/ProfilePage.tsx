import { motion } from 'framer-motion';
import { User, Mail, Calendar, Shield } from 'lucide-react';
import { useMember } from '@/integrations';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { format } from 'date-fns';
import { Image } from '@/components/ui/image';

export default function ProfilePage() {
  const { member } = useMember();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/20 rounded-2xl mb-6">
              <User className="w-10 h-10 text-primary" />
            </div>
            <h1 className="font-heading text-5xl lg:text-6xl font-bold mb-4">
              Your <span className="text-primary">Profile</span>
            </h1>
            <p className="font-paragraph text-lg text-foreground/70">
              Manage your account information
            </p>
          </div>

          {/* Profile Card */}
          <div className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8 lg:p-12 space-y-8">
            {/* Profile Picture */}
            <div className="flex flex-col items-center gap-4">
              <div className="w-32 h-32 rounded-2xl bg-primary/20 flex items-center justify-center overflow-hidden">
                {member?.profile?.photo?.url ? (
                  <Image src={member.profile.photo.url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-16 h-16 text-primary" />
                )}
              </div>
              <div className="text-center">
                <h2 className="font-heading text-2xl font-bold text-foreground">
                  {member?.profile?.nickname || member?.contact?.firstName || 'User'}
                </h2>
                {member?.profile?.title && (
                  <p className="font-paragraph text-foreground/60">{member.profile.title}</p>
                )}
              </div>
            </div>

            {/* Information Grid */}
            <div className="grid md:grid-cols-2 gap-6 pt-8 border-t border-foreground/10">
              {/* Email */}
              {member?.loginEmail && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground/60">
                    <Mail className="w-4 h-4 text-primary" />
                    <span className="font-paragraph text-sm font-semibold">Email</span>
                  </div>
                  <p className="font-paragraph text-foreground pl-6">
                    {member.loginEmail}
                  </p>
                  {member.loginEmailVerified && (
                    <div className="flex items-center gap-2 pl-6">
                      <Shield className="w-4 h-4 text-primary" />
                      <span className="font-paragraph text-xs text-primary">Verified</span>
                    </div>
                  )}
                </div>
              )}

              {/* Name */}
              {(member?.contact?.firstName || member?.contact?.lastName) && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground/60">
                    <User className="w-4 h-4 text-primary" />
                    <span className="font-paragraph text-sm font-semibold">Full Name</span>
                  </div>
                  <p className="font-paragraph text-foreground pl-6">
                    {[member.contact.firstName, member.contact.lastName].filter(Boolean).join(' ')}
                  </p>
                </div>
              )}

              {/* Phone */}
              {member?.contact?.phones && member.contact.phones.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground/60">
                    <Mail className="w-4 h-4 text-primary" />
                    <span className="font-paragraph text-sm font-semibold">Phone</span>
                  </div>
                  <p className="font-paragraph text-foreground pl-6">
                    {member.contact.phones[0]}
                  </p>
                </div>
              )}

              {/* Member Since */}
              {member?._createdDate && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground/60">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span className="font-paragraph text-sm font-semibold">Member Since</span>
                  </div>
                  <p className="font-paragraph text-foreground pl-6">
                    {format(new Date(member._createdDate), 'MMMM dd, yyyy')}
                  </p>
                </div>
              )}

              {/* Last Login */}
              {member?.lastLoginDate && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground/60">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span className="font-paragraph text-sm font-semibold">Last Login</span>
                  </div>
                  <p className="font-paragraph text-foreground pl-6">
                    {format(new Date(member.lastLoginDate), 'MMMM dd, yyyy')}
                  </p>
                </div>
              )}

              {/* Status */}
              {member?.status && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-foreground/60">
                    <Shield className="w-4 h-4 text-primary" />
                    <span className="font-paragraph text-sm font-semibold">Account Status</span>
                  </div>
                  <p className="font-paragraph text-foreground pl-6">
                    <span className={`inline-flex items-center px-3 py-1 rounded-lg text-xs font-semibold ${
                      member.status === 'APPROVED' ? 'bg-primary/20 text-primary' :
                      member.status === 'PENDING' ? 'bg-secondary/20 text-secondary' :
                      'bg-foreground/20 text-foreground'
                    }`}>
                      {member.status}
                    </span>
                  </p>
                </div>
              )}
            </div>

            {/* Info Box */}
            <div className="mt-8 p-6 bg-primary/5 border border-primary/20 rounded-xl">
              <h3 className="font-heading font-semibold text-foreground mb-3">
                Account Information
              </h3>
              <p className="font-paragraph text-sm text-foreground/70 leading-relaxed">
                Your profile information is securely stored and used to personalize your experience 
                on the LegalNexus platform. You can update your information through your account settings.
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
}
