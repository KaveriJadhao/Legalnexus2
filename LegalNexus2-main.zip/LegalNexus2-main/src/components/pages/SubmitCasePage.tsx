import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FileText, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BaseCrudService } from '@/integrations';
import { Cases } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useMember } from '@/integrations';

export default function SubmitCasePage() {
  const navigate = useNavigate();
  const { member, isAuthenticated } = useMember();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  
  const [formData, setFormData] = useState({
    caseType: '',
    problemDescription: '',
    urgencyLevel: '',
  });

  const caseTypes = [
    'Property Dispute',
    'Cybercrime',
    'Divorce & Family',
    'Criminal Defense',
    'Corporate Law',
    'Intellectual Property',
    'Labor & Employment',
    'Tax Law',
    'Immigration',
    'Consumer Protection',
  ];

  // AI-based urgency assessment
  const assessUrgency = (description: string, selectedUrgency: string): string => {
    if (selectedUrgency) return selectedUrgency;
    
    const urgentKeywords = ['urgent', 'emergency', 'immediate', 'asap', 'critical', 'arrest', 'deadline', 'court date'];
    const mediumKeywords = ['soon', 'important', 'need help', 'issue', 'problem'];
    
    const lowerDesc = description.toLowerCase();
    
    if (urgentKeywords.some(keyword => lowerDesc.includes(keyword))) {
      return 'High';
    } else if (mediumKeywords.some(keyword => lowerDesc.includes(keyword))) {
      return 'Medium';
    }
    
    return 'Low';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      alert('Please sign in to submit a case');
      return;
    }
    
    setIsSubmitting(true);

    const finalUrgency = assessUrgency(formData.problemDescription, formData.urgencyLevel);

    const newCase: Cases = {
      _id: crypto.randomUUID(),
      caseType: formData.caseType,
      problemDescription: formData.problemDescription,
      urgencyLevel: finalUrgency,
      caseStatus: 'Case Registered',
      submittedByUserId: member?._id || 'anonymous',
      submissionDate: new Date().toISOString(),
    };

    await BaseCrudService.create('cases', newCase);
    
    setIsSubmitting(false);
    setShowSuccess(true);
    
    setTimeout(() => {
      navigate('/dashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/20 rounded-2xl mb-6">
              <FileText className="w-10 h-10 text-primary" />
            </div>
            <h1 className="font-heading text-5xl lg:text-6xl font-bold mb-4">
              Submit Your <span className="text-primary">Case</span>
            </h1>
            <p className="font-paragraph text-lg text-foreground/70 max-w-2xl mx-auto">
              Fill out the form below and our AI will analyze your case to match you with the best lawyers
            </p>
          </div>

          {/* Success Message */}
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-8 p-6 bg-primary/10 border border-primary/30 rounded-xl flex items-center gap-4"
            >
              <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0" />
              <div>
                <h3 className="font-heading font-semibold text-foreground mb-1">Case Submitted Successfully!</h3>
                <p className="font-paragraph text-sm text-foreground/70">Redirecting to your dashboard...</p>
              </div>
            </motion.div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8 lg:p-12 space-y-8">
              {/* Case Type */}
              <div className="space-y-3">
                <Label htmlFor="caseType" className="font-heading text-lg font-semibold text-foreground">
                  Case Type *
                </Label>
                <Select
                  value={formData.caseType}
                  onValueChange={(value) => setFormData({ ...formData, caseType: value })}
                  required
                >
                  <SelectTrigger className="w-full bg-background/50 border-foreground/20 text-foreground font-paragraph h-12">
                    <SelectValue placeholder="Select case type" />
                  </SelectTrigger>
                  <SelectContent className="bg-charcoal border-foreground/20">
                    {caseTypes.map((type) => (
                      <SelectItem key={type} value={type} className="text-foreground font-paragraph">
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Problem Description */}
              <div className="space-y-3">
                <Label htmlFor="problemDescription" className="font-heading text-lg font-semibold text-foreground">
                  Problem Description *
                </Label>
                <Textarea
                  id="problemDescription"
                  value={formData.problemDescription}
                  onChange={(e) => setFormData({ ...formData, problemDescription: e.target.value })}
                  placeholder="Describe your legal issue in detail. Include relevant dates, parties involved, and any urgent matters..."
                  className="min-h-[200px] bg-background/50 border-foreground/20 text-foreground font-paragraph resize-none"
                  required
                />
                <p className="font-paragraph text-sm text-foreground/50 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Our AI will analyze keywords to assess urgency automatically
                </p>
              </div>

              {/* Urgency Level */}
              <div className="space-y-3">
                <Label htmlFor="urgencyLevel" className="font-heading text-lg font-semibold text-foreground">
                  Urgency Level (Optional)
                </Label>
                <Select
                  value={formData.urgencyLevel}
                  onValueChange={(value) => setFormData({ ...formData, urgencyLevel: value })}
                >
                  <SelectTrigger className="w-full bg-background/50 border-foreground/20 text-foreground font-paragraph h-12">
                    <SelectValue placeholder="AI will assess automatically" />
                  </SelectTrigger>
                  <SelectContent className="bg-charcoal border-foreground/20">
                    <SelectItem value="High" className="text-destructive font-paragraph">High - Urgent</SelectItem>
                    <SelectItem value="Medium" className="text-secondary font-paragraph">Medium - Important</SelectItem>
                    <SelectItem value="Low" className="text-primary font-paragraph">Low - Standard</SelectItem>
                  </SelectContent>
                </Select>
                <p className="font-paragraph text-sm text-foreground/50">
                  Leave blank for AI-powered urgency assessment based on your description
                </p>
              </div>

              {/* Info Box */}
              <div className="bg-primary/5 border border-primary/20 rounded-xl p-6">
                <h3 className="font-heading font-semibold text-foreground mb-3 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-primary" />
                  What Happens Next?
                </h3>
                <ul className="space-y-2 font-paragraph text-sm text-foreground/70">
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>AI analyzes your case type and description</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>System matches you with top 3 specialized lawyers</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>You'll receive lawyer recommendations on your dashboard</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    <span>Track your case progress in real-time</span>
                  </li>
                </ul>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={isSubmitting || !isAuthenticated}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 text-lg font-heading font-semibold rounded-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(0,255,255,0.5)] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                    Submitting Case...
                  </span>
                ) : !isAuthenticated ? (
                  'Please Sign In to Submit'
                ) : (
                  'Submit Case'
                )}
              </Button>
            </div>
          </form>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
}
