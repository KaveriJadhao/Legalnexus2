import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Star, Briefcase, Mail, Phone, Globe, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Image } from '@/components/ui/image';
import { BaseCrudService } from '@/integrations';
import { Lawyers } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function LawyersPage() {
  const [lawyers, setLawyers] = useState<Lawyers[]>([]);
  const [filteredLawyers, setFilteredLawyers] = useState<Lawyers[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterSpecialization, setFilterSpecialization] = useState('all');
  const [filterExperience, setFilterExperience] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadLawyers();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [lawyers, filterSpecialization, filterExperience, searchQuery]);

  const loadLawyers = async () => {
    setIsLoading(true);
    const result = await BaseCrudService.getAll<Lawyers>('lawyers');
    setLawyers(result.items);
    setIsLoading(false);
  };

  const applyFilters = () => {
    let filtered = [...lawyers];

    if (filterSpecialization !== 'all') {
      filtered = filtered.filter(lawyer => 
        lawyer.specialization?.toLowerCase().includes(filterSpecialization.toLowerCase())
      );
    }

    if (filterExperience !== 'all') {
      const minYears = parseInt(filterExperience);
      filtered = filtered.filter(lawyer => 
        (lawyer.experienceYears || 0) >= minYears
      );
    }

    if (searchQuery) {
      filtered = filtered.filter(lawyer =>
        lawyer.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lawyer.specialization?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort by rating
    filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));

    setFilteredLawyers(filtered);
  };

  const specializations = [
    'Property',
    'Cybercrime',
    'Divorce',
    'Criminal',
    'Corporate',
    'Intellectual Property',
    'Labor',
    'Tax',
    'Immigration',
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/20 rounded-2xl mb-6">
            <Users className="w-10 h-10 text-primary" />
          </div>
          <h1 className="font-heading text-5xl lg:text-6xl font-bold mb-4">
            Expert <span className="text-primary">Lawyers</span>
          </h1>
          <p className="font-paragraph text-lg text-foreground/70 max-w-2xl mx-auto">
            Browse our network of verified legal professionals and find the perfect match for your case
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12 bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <Filter className="w-5 h-5 text-primary" />
            <h2 className="font-heading text-xl font-semibold text-foreground">Filter Lawyers</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Input
                type="text"
                placeholder="Search by name or specialization..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-background/50 border-foreground/20 text-foreground font-paragraph"
              />
            </div>

            <div>
              <Select value={filterSpecialization} onValueChange={setFilterSpecialization}>
                <SelectTrigger className="bg-background/50 border-foreground/20 text-foreground font-paragraph">
                  <SelectValue placeholder="All Specializations" />
                </SelectTrigger>
                <SelectContent className="bg-charcoal border-foreground/20">
                  <SelectItem value="all" className="text-foreground font-paragraph">All Specializations</SelectItem>
                  {specializations.map((spec) => (
                    <SelectItem key={spec} value={spec} className="text-foreground font-paragraph">
                      {spec}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Select value={filterExperience} onValueChange={setFilterExperience}>
                <SelectTrigger className="bg-background/50 border-foreground/20 text-foreground font-paragraph">
                  <SelectValue placeholder="All Experience Levels" />
                </SelectTrigger>
                <SelectContent className="bg-charcoal border-foreground/20">
                  <SelectItem value="all" className="text-foreground font-paragraph">All Experience</SelectItem>
                  <SelectItem value="5" className="text-foreground font-paragraph">5+ Years</SelectItem>
                  <SelectItem value="10" className="text-foreground font-paragraph">10+ Years</SelectItem>
                  <SelectItem value="15" className="text-foreground font-paragraph">15+ Years</SelectItem>
                  <SelectItem value="20" className="text-foreground font-paragraph">20+ Years</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <p className="font-paragraph text-sm text-foreground/60">
              Showing {filteredLawyers.length} of {lawyers.length} lawyers
            </p>
            {(filterSpecialization !== 'all' || filterExperience !== 'all' || searchQuery) && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setFilterSpecialization('all');
                  setFilterExperience('all');
                  setSearchQuery('');
                }}
                className="border-foreground/20 text-foreground hover:bg-foreground/10 font-paragraph"
              >
                Clear Filters
              </Button>
            )}
          </div>
        </motion.div>

        {/* Lawyers Grid */}
        <div className="min-h-[400px]">
          {isLoading ? null : filteredLawyers.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredLawyers.map((lawyer, index) => (
                <motion.div
                  key={lawyer._id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="group bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6 hover:border-primary/50 transition-all duration-300"
                >
                  <div className="space-y-6">
                    {/* Profile Image */}
                    <div className="flex items-start gap-4">
                      <div className="w-20 h-20 rounded-xl overflow-hidden bg-primary/10 flex-shrink-0">
                        {lawyer.profileImage ? (
                          <Image
                            src={lawyer.profileImage}
                            alt={lawyer.name || 'Lawyer'}
                            width={80}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Users className="w-10 h-10 text-primary/50" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <h3 className="font-heading text-xl font-semibold text-foreground mb-1 truncate">
                          {lawyer.name}
                        </h3>
                        <p className="font-paragraph text-sm text-primary mb-2">
                          {lawyer.specialization}
                        </p>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-secondary fill-secondary" />
                          <span className="font-paragraph text-sm font-semibold text-foreground">
                            {lawyer.rating?.toFixed(1) || 'N/A'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Experience */}
                    <div className="flex items-center gap-2 text-foreground/70">
                      <Briefcase className="w-4 h-4 text-primary" />
                      <span className="font-paragraph text-sm">
                        {lawyer.experienceYears} years experience
                      </span>
                    </div>

                    {/* Contact Info */}
                    <div className="space-y-2 pt-4 border-t border-foreground/10">
                      {lawyer.email && (
                        <div className="flex items-center gap-2 text-foreground/60">
                          <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                          <span className="font-paragraph text-xs truncate">{lawyer.email}</span>
                        </div>
                      )}
                      {lawyer.phoneNumber && (
                        <div className="flex items-center gap-2 text-foreground/60">
                          <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                          <span className="font-paragraph text-xs">{lawyer.phoneNumber}</span>
                        </div>
                      )}
                      {lawyer.website && (
                        <div className="flex items-center gap-2 text-foreground/60">
                          <Globe className="w-4 h-4 text-primary flex-shrink-0" />
                          <a
                            href={lawyer.website}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="font-paragraph text-xs hover:text-primary transition-colors truncate"
                          >
                            {lawyer.website}
                          </a>
                        </div>
                      )}
                    </div>

                    {/* Contact Button */}
                    <Button className="w-full bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground border border-primary/30 font-heading font-semibold transition-all duration-300">
                      Contact Lawyer
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <Users className="w-16 h-16 text-foreground/30 mx-auto mb-4" />
              <h3 className="font-heading text-2xl font-semibold text-foreground mb-2">
                No Lawyers Found
              </h3>
              <p className="font-paragraph text-foreground/60">
                Try adjusting your filters to see more results
              </p>
            </motion.div>
          )}
        </div>
      </div>

      <Footer />
    </div>
  );
}
