// HPI 1.7-G
import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, useSpring, useInView } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Scale, Shield, FileText, MessageSquare, Users, TrendingUp, ChevronRight, Activity, Lock, Cpu, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Image } from '@/components/ui/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

// --- Types & Interfaces ---
interface Feature {
  icon: React.ElementType;
  title: string;
  description: string;
}

interface Stat {
  label: string;
  value: string;
  sub: string;
}

// --- Canonical Data Sources ---
const FEATURES_DATA: Feature[] = [
  {
    icon: FileText,
    title: 'Submit Your Case',
    description: 'Fill out a simple form with your case details and get instant priority assessment',
  },
  {
    icon: Users,
    title: 'AI-Matched Lawyers',
    description: 'Get matched with top 3 lawyers based on case type, experience, and ratings',
  },
  {
    icon: TrendingUp,
    title: 'Track Progress',
    description: 'Monitor your case status from registration to closure in real-time',
  },
  {
    icon: Shield,
    title: 'Secure Documents',
    description: 'Upload and manage case documents safely with lawyer access',
  },
  {
    icon: MessageSquare,
    title: 'Legal FAQ Bot',
    description: 'Get instant answers to common legal questions 24/7',
  },
  {
    icon: Scale,
    title: 'Smart Notifications',
    description: 'Receive alerts for case updates, lawyer messages, and hearing dates',
  },
];

const STATS_DATA: Stat[] = [
  { label: 'Cases Resolved', value: '500+', sub: 'Across 12 jurisdictions' },
  { label: 'Expert Lawyers', value: '150+', sub: 'Verified & Vetted' },
  { label: 'Success Rate', value: '98%', sub: 'Client Satisfaction' },
  { label: 'Response Time', value: '< 2m', sub: 'AI Analysis Speed' },
];

const WORKFLOW_STEPS = [
  {
    id: '01',
    title: 'Data Ingestion',
    desc: 'Submit case details via our secure, encrypted portal. Our system instantly categorizes urgency and type.',
    icon: FileText,
  },
  {
    id: '02',
    title: 'AI Analysis Core',
    desc: 'Our proprietary algorithms analyze keywords, legal precedents, and complexity to assign priority levels.',
    icon: Cpu,
  },
  {
    id: '03',
    title: 'Expert Matching',
    desc: 'The system scans our lawyer database to find the perfect match based on experience, win-rate, and specialization.',
    icon: Users,
  },
  {
    id: '04',
    title: 'Resolution Tracking',
    desc: 'Watch your case progress through real-time stages: Hearing Scheduled, Documents Verified, Case Closed.',
    icon: Activity,
  },
];

// --- Components ---

const SectionDivider = () => (
  <div className="w-full flex items-center justify-center py-12">
    <div className="h-[1px] w-24 bg-foreground/20" />
  </div>
);

export default function HomePage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);

  return (
    <div ref={containerRef} className="min-h-screen bg-background text-foreground font-paragraph selection:bg-foreground/10 selection:text-foreground overflow-clip">
      <style>{`
        .clip-corner-br {
          clip-path: polygon(0 0, 100% 0, 100% calc(100% - 20px), calc(100% - 20px) 100%, 0 100%);
        }
        .clip-corner-tl {
          clip-path: polygon(20px 0, 100% 0, 100% 100%, 0 100%, 0 20px);
        }
      `}</style>
      <Header />
      {/* --- HERO SECTION --- */}
      <section className="relative w-full min-h-screen flex flex-col justify-center pt-20 overflow-hidden bg-white">
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-8">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="flex items-center gap-3"
              >
                <div className="h-[1px] w-12 bg-foreground" />
                <span className="text-foreground font-mono text-xs tracking-[0.2em] uppercase">
                  Professional Legal Services
                </span>
              </motion.div>

              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 }}
                className="font-heading text-6xl lg:text-8xl font-bold leading-[0.9] tracking-tight text-foreground"
              >
                LEGAL <br />
                SOLUTIONS
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="text-lg lg:text-xl text-foreground/70 max-w-xl leading-relaxed border-l-2 border-foreground/30 pl-6"
              >
                Connect with experienced lawyers, submit cases, and track your legal matters in one simple platform.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="flex flex-wrap gap-6 pt-4"
              >
                <Link to="/submit-case">
                  <Button className="h-14 px-8 bg-foreground text-white hover:bg-foreground/90 rounded-lg transition-all duration-300 group font-heading font-bold">
                    <span className="mr-2">SUBMIT CASE</span>
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Link to="/lawyers">
                  <Button variant="outline" className="h-14 px-8 border-2 border-foreground text-foreground hover:bg-foreground/5 rounded-lg transition-colors font-heading font-bold">
                    BROWSE LAWYERS
                  </Button>
                </Link>
              </motion.div>
            </div>

            {/* Right Visual */}
            <div className="lg:col-span-5 relative h-[600px] hidden lg:block">
              <motion.div 
                style={{ y, opacity }}
                className="absolute inset-0 flex items-center justify-center"
              >

              </motion.div>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <span className="text-[10px] font-mono text-foreground/40 tracking-[0.3em]">SCROLL DOWN</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-foreground to-transparent" />
        </motion.div>
      </section>
      {/* --- STATS STRIP --- */}
      <section className="w-full border-y border-foreground/10 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-foreground/10">
            {STATS_DATA.map((stat, index) => (
              <div key={index} className="py-8 px-4 text-center group hover:bg-foreground/5 transition-colors duration-300">
                <div className="font-heading text-3xl lg:text-4xl font-bold text-foreground mb-1 group-hover:text-foreground/80 transition-colors">
                  {stat.value}
                </div>
                <div className="text-xs font-mono text-foreground/60 uppercase tracking-wider mb-1">{stat.label}</div>
                <div className="text-[10px] text-foreground/40">{stat.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* --- WORKFLOW SECTION (Sticky) --- */}
      <section className="relative w-full py-32 bg-white">
        <div className="container mx-auto px-6">
          <div className="mb-20">
            <h2 className="font-heading text-4xl lg:text-6xl font-bold mb-6 text-foreground">
              HOW IT WORKS
            </h2>
            <p className="text-foreground/60 max-w-2xl text-lg">
              A straightforward process to connect you with the right legal expertise.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-12">
            {/* Sticky Navigation/Indicator */}

            {/* Steps List */}
            <div className="lg:col-span-8 space-y-24">
              {WORKFLOW_STEPS.map((step, index) => (
                <WorkflowStep key={step.id} step={step} index={index} />
              ))}
            </div>
          </div>
        </div>
      </section>
      <SectionDivider />
      {/* --- FEATURES GRID --- */}
      <section className="relative w-full py-24 bg-gray-50">
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-2 bg-foreground rounded-full" />
                <span className="text-foreground/60 font-mono text-xs tracking-widest">FEATURES</span>
              </div>
              <h2 className="font-heading text-4xl lg:text-5xl font-bold text-foreground">
                Platform <span className="text-foreground/70">Features</span>
              </h2>
            </div>
            <Link to="/features">
              <Button variant="outline" className="border-foreground/20 hover:bg-foreground/5 text-foreground font-paragraph">
                View All
              </Button>
            </Link>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES_DATA.map((feature, index) => (
              <FeatureCard key={index} feature={feature} index={index} />
            ))}
          </div>
        </div>
      </section>
      {/* --- CTA SECTION --- */}
      <section className="relative w-full py-32 overflow-hidden bg-white">
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-5xl mx-auto relative">
            <div className="bg-white border-2 border-foreground/20 rounded-lg p-12 lg:p-24 text-center">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="font-heading text-5xl lg:text-7xl font-bold mb-8 text-foreground">
                  Ready to Get Started?
                </h2>
                <p className="font-paragraph text-xl text-foreground/70 max-w-2xl mx-auto mb-12">
                  Submit your case today and connect with experienced legal professionals.
                </p>
                
                <div className="flex flex-col sm:flex-row justify-center gap-6">
                  <Link to="/submit-case">
                    <Button className="w-full sm:w-auto h-16 px-10 bg-foreground text-white hover:bg-foreground/90 text-lg font-heading font-bold rounded-lg transition-all duration-300">
                      SUBMIT CASE
                    </Button>
                  </Link>
                  <Link to="/faq">
                    <Button variant="outline" className="w-full sm:w-auto h-16 px-10 border-2 border-foreground/20 hover:bg-foreground/5 text-foreground text-lg font-heading font-bold rounded-lg">
                      LEARN MORE
                    </Button>
                  </Link>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
}

// --- Sub-Components ---

function WorkflowStep({ step, index }: { step: any, index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { margin: "-20% 0px -20% 0px", once: true });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: 50 }}
      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0.3, x: 50 }}
      transition={{ duration: 0.8 }}
      className="flex gap-8 group"
    >
      <div className="hidden md:flex flex-col items-center">
        <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center text-sm font-mono font-bold transition-colors duration-500 ${isInView ? 'border-foreground text-foreground bg-foreground/10' : 'border-foreground/20 text-foreground/30'}`}>
          {step.id}
        </div>
        {index !== 3 && <div className="w-[1px] h-full bg-foreground/10 mt-4 group-hover:bg-foreground/30 transition-colors" />}
      </div>
      
      <div className="flex-1 pt-2">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-gray-100 rounded-lg border border-foreground/20 text-foreground">
            <step.icon className="w-6 h-6" />
          </div>
          <h3 className="font-heading text-3xl font-bold text-foreground">{step.title}</h3>
        </div>
        <p className="text-foreground/60 text-lg leading-relaxed max-w-xl">
          {step.desc}
        </p>
      </div>
    </motion.div>
  );
}

function FeatureCard({ feature, index }: { feature: Feature, index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="group relative p-8 bg-white border-2 border-foreground/10 hover:border-foreground/30 transition-all duration-500 overflow-hidden rounded-lg"
    >
      {/* Hover Background */}
      <div className="absolute inset-0 bg-gray-50 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <div className="relative z-10 space-y-6">
        <div className="w-14 h-14 bg-gray-100 rounded-lg flex items-center justify-center border border-foreground/20 group-hover:scale-110 transition-transform duration-500">
          <feature.icon className="w-7 h-7 text-foreground" />
        </div>
        
        <div>
          <h3 className="font-heading text-xl font-bold mb-3 group-hover:text-foreground/80 transition-colors">
            {feature.title}
          </h3>
          <p className="text-sm text-foreground/60 leading-relaxed">
            {feature.description}
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-foreground/40 group-hover:text-foreground/60 transition-colors">
          <span>ACTIVE</span>
          <div className="w-1 h-1 bg-current rounded-full" />
        </div>
      </div>
    </motion.div>
  );
}