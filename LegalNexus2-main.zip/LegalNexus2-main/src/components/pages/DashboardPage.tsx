import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { LayoutDashboard, FileText, Upload, Bell, CheckCircle2, Clock, AlertCircle, Users, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { BaseCrudService } from '@/integrations';
import { Cases, CaseDocuments, Notifications, Lawyers } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useMember } from '@/integrations';
import { format } from 'date-fns';
import { Image } from '@/components/ui/image';

export default function DashboardPage() {
  const { member, isAuthenticated } = useMember();
  const [cases, setCases] = useState<Cases[]>([]);
  const [documents, setDocuments] = useState<CaseDocuments[]>([]);
  const [notifications, setNotifications] = useState<Notifications[]>([]);
  const [recommendedLawyers, setRecommendedLawyers] = useState<Lawyers[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCase, setSelectedCase] = useState<string>('');
  const [uploadingDoc, setUploadingDoc] = useState(false);

  useEffect(() => {
    if (isAuthenticated) {
      loadDashboardData();
    }
  }, [isAuthenticated, member]);

  const loadDashboardData = async () => {
    setIsLoading(true);
    
    const casesResult = await BaseCrudService.getAll<Cases>('cases');
    const userCases = casesResult.items.filter(c => c.submittedByUserId === member?._id);
    setCases(userCases);

    if (userCases.length > 0) {
      setSelectedCase(userCases[0]._id);
      
      const docsResult = await BaseCrudService.getAll<CaseDocuments>('casedocuments');
      const caseDocs = docsResult.items.filter(d => d.caseId === userCases[0]._id);
      setDocuments(caseDocs);

      // Get recommended lawyers based on latest case
      const latestCase = userCases[0];
      const lawyersResult = await BaseCrudService.getAll<Lawyers>('lawyers');
      const matched = lawyersResult.items
        .filter(l => l.specialization?.toLowerCase().includes(latestCase.caseType?.split(' ')[0].toLowerCase() || ''))
        .sort((a, b) => {
          const ratingDiff = (b.rating || 0) - (a.rating || 0);
          if (ratingDiff !== 0) return ratingDiff;
          return (b.experienceYears || 0) - (a.experienceYears || 0);
        })
        .slice(0, 3);
      setRecommendedLawyers(matched);
    }

    const notifResult = await BaseCrudService.getAll<Notifications>('notifications');
    const userNotifs = notifResult.items
      .filter(n => n.recipientUserId === member?._id)
      .sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime())
      .slice(0, 5);
    setNotifications(userNotifs);

    setIsLoading(false);
  };

  const handleDocumentUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedCase) return;

    setUploadingDoc(true);

    const formData = new FormData(e.currentTarget);
    const documentName = formData.get('documentName') as string;
    const fileType = formData.get('fileType') as string;

    const newDoc: CaseDocuments = {
      _id: crypto.randomUUID(),
      documentName,
      documentUrl: 'https://example.com/documents/' + crypto.randomUUID(),
      caseId: selectedCase,
      uploadDate: new Date().toISOString(),
      fileType,
    };

    await BaseCrudService.create('casedocuments', newDoc);
    
    setDocuments([...documents, newDoc]);
    setUploadingDoc(false);
    
    (e.target as HTMLFormElement).reset();
  };

  const markNotificationRead = async (notificationId: string) => {
    await BaseCrudService.update<Notifications>('notifications', {
      _id: notificationId,
      isRead: true,
    });
    
    setNotifications(notifications.map(n => 
      n._id === notificationId ? { ...n, isRead: true } : n
    ));
  };

  const caseStages = [
    'Case Registered',
    'Lawyer Assigned',
    'Documents Uploaded',
    'Hearing Scheduled',
    'Case Closed',
  ];

  const getCurrentStageIndex = (status?: string) => {
    return caseStages.indexOf(status || 'Case Registered');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-32 text-center">
          <AlertCircle className="w-16 h-16 text-primary mx-auto mb-4" />
          <h2 className="font-heading text-3xl font-bold mb-4">Sign In Required</h2>
          <p className="font-paragraph text-foreground/70 mb-8">Please sign in to access your dashboard</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center">
              <LayoutDashboard className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h1 className="font-heading text-4xl lg:text-5xl font-bold">
                Your <span className="text-primary">Dashboard</span>
              </h1>
              <p className="font-paragraph text-foreground/70">
                Welcome back, {member?.profile?.nickname || member?.contact?.firstName || 'User'}
              </p>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Case Status Tracker */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8"
            >
              <div className="flex items-center gap-3 mb-8">
                <FileText className="w-6 h-6 text-primary" />
                <h2 className="font-heading text-2xl font-semibold text-foreground">Case Status Tracker</h2>
              </div>

              {isLoading ? null : cases.length > 0 ? (
                <div className="space-y-8">
                  {cases.map((caseItem) => {
                    const currentStage = getCurrentStageIndex(caseItem.caseStatus);
                    
                    return (
                      <div key={caseItem._id} className="space-y-6">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <h3 className="font-heading text-xl font-semibold text-foreground mb-2">
                              {caseItem.caseType}
                            </h3>
                            <p className="font-paragraph text-sm text-foreground/60 line-clamp-2">
                              {caseItem.problemDescription}
                            </p>
                            <div className="flex items-center gap-4 mt-3">
                              <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-lg text-xs font-paragraph font-semibold ${
                                caseItem.urgencyLevel === 'High' ? 'bg-destructive/20 text-destructive' :
                                caseItem.urgencyLevel === 'Medium' ? 'bg-secondary/20 text-secondary' :
                                'bg-primary/20 text-primary'
                              }`}>
                                {caseItem.urgencyLevel} Priority
                              </span>
                              <span className="font-paragraph text-xs text-foreground/50">
                                {caseItem.submissionDate && format(new Date(caseItem.submissionDate), 'MMM dd, yyyy')}
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Progress Tracker */}
                        <div className="relative">
                          <div className="flex justify-between">
                            {caseStages.map((stage, index) => (
                              <div key={stage} className="flex flex-col items-center flex-1">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                                  index <= currentStage
                                    ? 'bg-primary border-primary'
                                    : 'bg-background border-foreground/20'
                                }`}>
                                  {index < currentStage ? (
                                    <CheckCircle2 className="w-5 h-5 text-primary-foreground" />
                                  ) : index === currentStage ? (
                                    <Clock className="w-5 h-5 text-primary-foreground" />
                                  ) : (
                                    <span className="text-xs font-semibold text-foreground/40">{index + 1}</span>
                                  )}
                                </div>
                                <span className={`mt-2 text-xs font-paragraph text-center ${
                                  index <= currentStage ? 'text-foreground font-semibold' : 'text-foreground/40'
                                }`}>
                                  {stage}
                                </span>
                              </div>
                            ))}
                          </div>
                          <div className="absolute top-5 left-0 right-0 h-0.5 bg-foreground/10 -z-10">
                            <div
                              className="h-full bg-primary transition-all duration-500"
                              style={{ width: `${(currentStage / (caseStages.length - 1)) * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
                  <p className="font-paragraph text-foreground/60 mb-4">No cases submitted yet</p>
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-heading">
                    Submit Your First Case
                  </Button>
                </div>
              )}
            </motion.div>

            {/* Document Upload */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8"
            >
              <div className="flex items-center gap-3 mb-6">
                <Upload className="w-6 h-6 text-primary" />
                <h2 className="font-heading text-2xl font-semibold text-foreground">Upload Documents</h2>
              </div>

              {cases.length > 0 ? (
                <form onSubmit={handleDocumentUpload} className="space-y-6">
                  <div className="space-y-3">
                    <Label className="font-paragraph text-foreground">Document Name</Label>
                    <Input
                      name="documentName"
                      placeholder="e.g., Property Deed, Evidence Photo"
                      required
                      className="bg-background/50 border-foreground/20 text-foreground font-paragraph"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="font-paragraph text-foreground">File Type</Label>
                    <Input
                      name="fileType"
                      placeholder="e.g., PDF, JPG, PNG"
                      required
                      className="bg-background/50 border-foreground/20 text-foreground font-paragraph"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={uploadingDoc}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-heading font-semibold"
                  >
                    {uploadingDoc ? 'Uploading...' : 'Upload Document'}
                  </Button>
                </form>
              ) : (
                <p className="font-paragraph text-foreground/60 text-center py-8">
                  Submit a case first to upload documents
                </p>
              )}

              {/* Documents List */}
              {documents.length > 0 && (
                <div className="mt-8 pt-8 border-t border-foreground/10 space-y-3">
                  <h3 className="font-heading font-semibold text-foreground mb-4">Uploaded Documents</h3>
                  {documents.map((doc) => (
                    <div key={doc._id} className="flex items-center justify-between p-4 bg-background/50 rounded-lg">
                      <div>
                        <p className="font-paragraph font-semibold text-foreground">{doc.documentName}</p>
                        <p className="font-paragraph text-xs text-foreground/50">
                          {doc.fileType} • {doc.uploadDate && format(new Date(doc.uploadDate), 'MMM dd, yyyy')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>

            {/* Recommended Lawyers */}
            {recommendedLawyers.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8"
              >
                <div className="flex items-center gap-3 mb-6">
                  <Users className="w-6 h-6 text-primary" />
                  <h2 className="font-heading text-2xl font-semibold text-foreground">Recommended Lawyers</h2>
                </div>

                <div className="space-y-4">
                  {recommendedLawyers.map((lawyer) => (
                    <div key={lawyer._id} className="flex items-center gap-4 p-4 bg-background/50 rounded-lg hover:bg-background/70 transition-colors">
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-primary/10 flex-shrink-0">
                        {lawyer.profileImage ? (
                          <Image
                            src={lawyer.profileImage}
                            alt={lawyer.name || 'Lawyer'}
                            width={64}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Users className="w-8 h-8 text-primary/50" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-heading font-semibold text-foreground">{lawyer.name}</h3>
                        <p className="font-paragraph text-sm text-primary">{lawyer.specialization}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-secondary fill-secondary" />
                            <span className="font-paragraph text-xs text-foreground/70">{lawyer.rating?.toFixed(1)}</span>
                          </div>
                          <span className="font-paragraph text-xs text-foreground/50">
                            {lawyer.experienceYears} years exp.
                          </span>
                        </div>
                      </div>
                      <Button size="sm" className="bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground border border-primary/30 font-paragraph">
                        Contact
                      </Button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Sidebar - Notifications */}
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6 sticky top-24"
            >
              <div className="flex items-center gap-3 mb-6">
                <Bell className="w-5 h-5 text-primary" />
                <h2 className="font-heading text-xl font-semibold text-foreground">Notifications</h2>
              </div>

              {isLoading ? null : notifications.length > 0 ? (
                <div className="space-y-3">
                  {notifications.map((notif) => (
                    <div
                      key={notif._id}
                      className={`p-4 rounded-lg border transition-all duration-300 cursor-pointer ${
                        notif.isRead
                          ? 'bg-background/30 border-foreground/10'
                          : 'bg-primary/5 border-primary/20'
                      }`}
                      onClick={() => !notif.isRead && markNotificationRead(notif._id)}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                          notif.isRead ? 'bg-foreground/30' : 'bg-primary'
                        }`} />
                        <div className="flex-1 min-w-0">
                          <p className="font-paragraph text-sm text-foreground mb-1">
                            {notif.message}
                          </p>
                          <p className="font-paragraph text-xs text-foreground/50">
                            {notif.timestamp && format(new Date(notif.timestamp), 'MMM dd, h:mm a')}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Bell className="w-10 h-10 text-foreground/30 mx-auto mb-3" />
                  <p className="font-paragraph text-sm text-foreground/60">No notifications yet</p>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
