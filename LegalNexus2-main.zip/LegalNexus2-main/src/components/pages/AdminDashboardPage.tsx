import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, Users, FileText, Briefcase, AlertTriangle, TrendingUp, Activity } from 'lucide-react';
import { BaseCrudService } from '@/integrations';
import { Cases, Lawyers, Complaints, Notifications } from '@/entities';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { format } from 'date-fns';

export default function AdminDashboardPage() {
  const [stats, setStats] = useState({
    totalCases: 0,
    activeCases: 0,
    totalLawyers: 0,
    totalComplaints: 0,
    unresolvedComplaints: 0,
  });
  const [recentCases, setRecentCases] = useState<Cases[]>([]);
  const [recentComplaints, setRecentComplaints] = useState<Complaints[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    setIsLoading(true);

    const casesResult = await BaseCrudService.getAll<Cases>('cases');
    const lawyersResult = await BaseCrudService.getAll<Lawyers>('lawyers');
    const complaintsResult = await BaseCrudService.getAll<Complaints>('complaints');

    const activeCases = casesResult.items.filter(c => 
      c.caseStatus !== 'Case Closed'
    );

    const unresolvedComplaints = complaintsResult.items.filter(c =>
      c.resolutionStatus !== 'Resolved'
    );

    setStats({
      totalCases: casesResult.items.length,
      activeCases: activeCases.length,
      totalLawyers: lawyersResult.items.length,
      totalComplaints: complaintsResult.items.length,
      unresolvedComplaints: unresolvedComplaints.length,
    });

    setRecentCases(
      casesResult.items
        .sort((a, b) => new Date(b.submissionDate || 0).getTime() - new Date(a.submissionDate || 0).getTime())
        .slice(0, 5)
    );

    setRecentComplaints(
      complaintsResult.items
        .sort((a, b) => new Date(b.submissionDate || 0).getTime() - new Date(a.submissionDate || 0).getTime())
        .slice(0, 5)
    );

    setIsLoading(false);
  };

  const statCards = [
    {
      title: 'Total Cases',
      value: stats.totalCases,
      icon: FileText,
      color: 'primary',
      bgColor: 'bg-primary/20',
      textColor: 'text-primary',
    },
    {
      title: 'Active Cases',
      value: stats.activeCases,
      icon: Activity,
      color: 'secondary',
      bgColor: 'bg-secondary/20',
      textColor: 'text-secondary',
    },
    {
      title: 'Active Lawyers',
      value: stats.totalLawyers,
      icon: Briefcase,
      color: 'primary',
      bgColor: 'bg-primary/20',
      textColor: 'text-primary',
    },
    {
      title: 'Total Complaints',
      value: stats.totalComplaints,
      icon: AlertTriangle,
      color: 'destructive',
      bgColor: 'bg-destructive/20',
      textColor: 'text-destructive',
    },
    {
      title: 'Unresolved Complaints',
      value: stats.unresolvedComplaints,
      icon: AlertTriangle,
      color: 'destructive',
      bgColor: 'bg-destructive/20',
      textColor: 'text-destructive',
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="max-w-[100rem] mx-auto px-8 lg:px-16 py-16">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-secondary/20 rounded-2xl flex items-center justify-center">
              <Shield className="w-8 h-8 text-secondary" />
            </div>
            <div>
              <h1 className="font-heading text-4xl lg:text-5xl font-bold">
                Admin <span className="text-secondary">Dashboard</span>
              </h1>
              <p className="font-paragraph text-foreground/70">
                Platform overview and management
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-12">
          {statCards.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-6 hover:border-primary/30 transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                  <stat.icon className={`w-6 h-6 ${stat.textColor}`} />
                </div>
              </div>
              <div>
                <p className="font-paragraph text-sm text-foreground/60 mb-1">{stat.title}</p>
                <p className={`font-heading text-3xl font-bold ${stat.textColor}`}>
                  {isLoading ? '-' : stat.value}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Cases */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <FileText className="w-6 h-6 text-primary" />
              <h2 className="font-heading text-2xl font-semibold text-foreground">Recent Cases</h2>
            </div>

            {isLoading ? null : recentCases.length > 0 ? (
              <div className="space-y-4">
                {recentCases.map((caseItem) => (
                  <div
                    key={caseItem._id}
                    className="p-4 bg-background/50 rounded-lg border border-foreground/10 hover:border-primary/30 transition-all duration-300"
                  >
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <h3 className="font-heading font-semibold text-foreground">
                        {caseItem.caseType}
                      </h3>
                      <span className={`px-3 py-1 rounded-lg text-xs font-paragraph font-semibold whitespace-nowrap ${
                        caseItem.urgencyLevel === 'High' ? 'bg-destructive/20 text-destructive' :
                        caseItem.urgencyLevel === 'Medium' ? 'bg-secondary/20 text-secondary' :
                        'bg-primary/20 text-primary'
                      }`}>
                        {caseItem.urgencyLevel}
                      </span>
                    </div>
                    <p className="font-paragraph text-sm text-foreground/60 line-clamp-2 mb-3">
                      {caseItem.problemDescription}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="font-paragraph text-xs text-foreground/50">
                        {caseItem.submissionDate && format(new Date(caseItem.submissionDate), 'MMM dd, yyyy')}
                      </span>
                      <span className="font-paragraph text-xs text-primary">
                        {caseItem.caseStatus}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
                <p className="font-paragraph text-foreground/60">No cases yet</p>
              </div>
            )}
          </motion.div>

          {/* Recent Complaints */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <AlertTriangle className="w-6 h-6 text-destructive" />
              <h2 className="font-heading text-2xl font-semibold text-foreground">Recent Complaints</h2>
            </div>

            {isLoading ? null : recentComplaints.length > 0 ? (
              <div className="space-y-4">
                {recentComplaints.map((complaint) => (
                  <div
                    key={complaint._id}
                    className="p-4 bg-background/50 rounded-lg border border-foreground/10 hover:border-destructive/30 transition-all duration-300"
                  >
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <h3 className="font-heading font-semibold text-foreground">
                        {complaint.complaintTitle}
                      </h3>
                      <span className={`px-3 py-1 rounded-lg text-xs font-paragraph font-semibold whitespace-nowrap ${
                        complaint.resolutionStatus === 'Resolved'
                          ? 'bg-primary/20 text-primary'
                          : 'bg-destructive/20 text-destructive'
                      }`}>
                        {complaint.resolutionStatus || 'Pending'}
                      </span>
                    </div>
                    <p className="font-paragraph text-sm text-foreground/60 line-clamp-2 mb-3">
                      {complaint.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="font-paragraph text-xs text-foreground/50">
                        By: {complaint.submittedBy || 'Anonymous'}
                      </span>
                      <span className="font-paragraph text-xs text-foreground/50">
                        {complaint.submissionDate && format(new Date(complaint.submissionDate), 'MMM dd, yyyy')}
                      </span>
                    </div>
                    {complaint.adminNotes && (
                      <div className="mt-3 pt-3 border-t border-foreground/10">
                        <p className="font-paragraph text-xs text-foreground/50">
                          <span className="font-semibold">Admin Notes:</span> {complaint.adminNotes}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <AlertTriangle className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
                <p className="font-paragraph text-foreground/60">No complaints yet</p>
              </div>
            )}
          </motion.div>
        </div>

        {/* System Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-8 bg-glassmorphism-overlay backdrop-blur-sm border border-foreground/10 rounded-2xl p-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-primary" />
            <h2 className="font-heading text-2xl font-semibold text-foreground">Platform Insights</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-6 bg-background/50 rounded-xl border border-foreground/10">
              <p className="font-paragraph text-sm text-foreground/60 mb-2">Case Resolution Rate</p>
              <p className="font-heading text-3xl font-bold text-primary">
                {stats.totalCases > 0 
                  ? Math.round(((stats.totalCases - stats.activeCases) / stats.totalCases) * 100)
                  : 0}%
              </p>
            </div>

            <div className="p-6 bg-background/50 rounded-xl border border-foreground/10">
              <p className="font-paragraph text-sm text-foreground/60 mb-2">Complaint Resolution Rate</p>
              <p className="font-heading text-3xl font-bold text-secondary">
                {stats.totalComplaints > 0
                  ? Math.round(((stats.totalComplaints - stats.unresolvedComplaints) / stats.totalComplaints) * 100)
                  : 0}%
              </p>
            </div>

            <div className="p-6 bg-background/50 rounded-xl border border-foreground/10">
              <p className="font-paragraph text-sm text-foreground/60 mb-2">Avg. Cases per Lawyer</p>
              <p className="font-heading text-3xl font-bold text-primary">
                {stats.totalLawyers > 0
                  ? (stats.totalCases / stats.totalLawyers).toFixed(1)
                  : 0}
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
}
