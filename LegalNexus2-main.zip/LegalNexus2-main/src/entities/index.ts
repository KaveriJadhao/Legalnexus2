/**
 * Auto-generated entity types
 * Contains all CMS collection interfaces in a single file 
 */

/**
 * Collection ID: casedocuments
 * Interface for CaseDocuments
 */
export interface CaseDocuments {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  documentName?: string;
  /** @wixFieldType url */
  documentUrl?: string;
  /** @wixFieldType text */
  caseId?: string;
  /** @wixFieldType datetime */
  uploadDate?: Date | string;
  /** @wixFieldType text */
  fileType?: string;
}


/**
 * Collection ID: cases
 * Interface for Cases
 */
export interface Cases {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  caseType?: string;
  /** @wixFieldType text */
  problemDescription?: string;
  /** @wixFieldType text */
  urgencyLevel?: string;
  /** @wixFieldType text */
  caseStatus?: string;
  /** @wixFieldType text */
  submittedByUserId?: string;
  /** @wixFieldType datetime */
  submissionDate?: Date | string;
}


/**
 * Collection ID: complaints
 * Interface for Complaints
 */
export interface Complaints {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  complaintTitle?: string;
  /** @wixFieldType text */
  description?: string;
  /** @wixFieldType text */
  submittedBy?: string;
  /** @wixFieldType text */
  caseReference?: string;
  /** @wixFieldType datetime */
  submissionDate?: Date | string;
  /** @wixFieldType text */
  resolutionStatus?: string;
  /** @wixFieldType text */
  adminNotes?: string;
}


/**
 * Collection ID: lawyers
 * Interface for Lawyers
 */
export interface Lawyers {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  name?: string;
  /** @wixFieldType image - Contains image URL, render with <Image> component, NOT as text */
  profileImage?: string;
  /** @wixFieldType text */
  specialization?: string;
  /** @wixFieldType number */
  experienceYears?: number;
  /** @wixFieldType number */
  rating?: number;
  /** @wixFieldType text */
  email?: string;
  /** @wixFieldType text */
  phoneNumber?: string;
  /** @wixFieldType url */
  website?: string;
}


/**
 * Collection ID: legalfaqs
 * Interface for LegalFAQs
 */
export interface LegalFAQs {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  questionText?: string;
  /** @wixFieldType text */
  answerText?: string;
  /** @wixFieldType text */
  keywords?: string;
  /** @wixFieldType text */
  category?: string;
  /** @wixFieldType number */
  priorityLevel?: number;
}


/**
 * Collection ID: notifications
 * Interface for Notifications
 */
export interface Notifications {
  _id: string;
  _createdDate?: Date;
  _updatedDate?: Date;
  /** @wixFieldType text */
  message?: string;
  /** @wixFieldType text */
  notificationType?: string;
  /** @wixFieldType datetime */
  timestamp?: Date | string;
  /** @wixFieldType text */
  caseReferenceId?: string;
  /** @wixFieldType boolean */
  isRead?: boolean;
  /** @wixFieldType text */
  recipientUserId?: string;
}
