// Re-export from main entities file for backward compatibility
export type { Lawyers } from './index';
