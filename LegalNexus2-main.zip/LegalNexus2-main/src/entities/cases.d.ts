// Re-export from main entities file for backward compatibility
export type { Cases } from './index';
