import config from "./src/tailwind.config.mjs";

export default config;